$(document).ready(function(){
	$('#menu').slicknav();
    $("#responsive-videos").fitVids();
});